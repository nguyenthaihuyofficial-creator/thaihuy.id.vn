function kiemTra() {
    var MaNV = document.getElementById('MaNV').value.trim();
    var HoTen = document.getElementById('HoTen').value.trim();
    var NgaySinh = document.getElementById('NgaySinh').value;
    var Luong = document.getElementById('Luong').value;
    var MaPB = document.getElementById('MaPB').value;

    if (MaNV == "" || HoTen == "" || NgaySinh == "" || Luong == "") {
        alert("Vui lòng nhập đầy đủ!");
        return false;
    }
    if (MaNV.length > 4) {
        alert("Mã nhân viên không được quá 4 ký tự!");
        return false;
    }
    if (!/^\d{1,12}$/.test(Luong) || Number(Luong) < 1) {
        alert("Lương không hợp lệ!");
        return false;
    }
    // Check select
    if (MaPB == "") {
        alert("Vui lòng chọn phòng ban!");
        return false;
    }
    return true;
}

function xacNhanXoa() {
    return confirm("Bạn có chắc chắn muốn xóa nhân viên này?");
}
