<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli('localhost', 'root', '', 'QLNhanVien');
$conn->set_charset('utf8mb4');
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$loi = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 try {
  if (isset($_POST['them'])) {
   $ma = trim($_POST['MaNV'] ?? '');
   $ten = trim($_POST['HoTen'] ?? '');
   $ngay = $_POST['NgaySinh'] ?? '';
   $luong = $_POST['Luong'] ?? '';
   $pb = filter_var($_POST['MaPB'] ?? '', FILTER_VALIDATE_INT);
   $date = DateTime::createFromFormat('!Y-m-d', $ngay);
   if ($ma === '' || mb_strlen($ma) > 4 || $ten === '' || mb_strlen($ten) > 100 || !$date || $date->format('Y-m-d') !== $ngay || (!preg_match('/^\d{1,12}$/D', $luong) || (float)$luong < 1) || !$pb) {
    throw new Exception('Vui lòng nhập đầy đủ và đúng định dạng.');
   }
   $stmt = $conn->prepare('INSERT INTO NhanVien (MaNV,HoTen,NgaySinh,Luong,MaPB) VALUES (?,?,?,?,?)');
   $stmt->bind_param('ssssi', $ma,$ten,$ngay,$luong,$pb);
   $stmt->execute();
  } elseif (isset($_POST['xoa'])) {
   $ma = $_POST['MaNV'] ?? '';
   $stmt = $conn->prepare('DELETE FROM NhanVien WHERE MaNV=?');
   $stmt->bind_param('s',$ma);
   $stmt->execute();
  }
  header('Location: NhanVien.php'); exit;
 } catch (mysqli_sql_exception $e) {
  $loi = $e->getCode() == 1062 ? 'Mã nhân viên đã tồn tại.' : 'Không thể thực hiện thao tác. Kiểm tra dữ liệu phòng ban.';
 } catch (Exception $e) { $loi = $e->getMessage(); }
}
$phongban = $conn->query('SELECT MaPB, TenPB FROM PhongBan ORDER BY MaPB');
$nhanvien = $conn->query('SELECT n.MaNV,n.HoTen,n.NgaySinh,n.Luong,p.TenPB FROM NhanVien n JOIN PhongBan p ON n.MaPB=p.MaPB ORDER BY n.MaNV');
?>
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý nhân viên</title>
<link rel="stylesheet" href="style.css">
<script src="script.js" defer></script></head><body><main class="khung">
<?php if ($loi): ?><p class="loi"><?=h($loi)?></p><?php endif; ?>
<form class="nhap" method="post" onsubmit="return kiemTra();" novalidate>
<div class="nhom"><label for="MaNV">Mã nhân viên <span>*</span></label><input id="MaNV" name="MaNV" maxlength="4" required></div>
<div class="nhom"><label for="HoTen">Họ tên <span>*</span></label><input id="HoTen" name="HoTen" maxlength="100" required></div>
<div class="nhom"><label for="NgaySinh">Ngày sinh <span>*</span></label><input type="date" id="NgaySinh" name="NgaySinh" required></div>
<div class="nhom"><label for="Luong">Lương <span>*</span></label><input type="number" id="Luong" name="Luong" min="1" max="999999999999" step="1" required></div>
<div class="nhom"><label for="MaPB">Phòng ban <span>*</span></label><select id="MaPB" name="MaPB" required><option value="">-- Chọn phòng ban --</option><?php while($p=$phongban->fetch_assoc()): ?><option value="<?=h($p['MaPB'])?>"><?=h($p['TenPB'])?></option><?php endwhile; ?></select></div>
<button class="them" name="them" value="1">Thêm NV</button></form>
<div class="bang"><table><thead><tr><th>Mã NV</th><th>Họ tên</th><th>Ngày sinh</th><th>Lương</th><th>Tên phòng ban</th><th>Thao tác</th></tr></thead><tbody>
<?php while($n=$nhanvien->fetch_assoc()): ?><tr><td><?=h($n['MaNV'])?></td><td><?=h($n['HoTen'])?></td><td><?=h($n['NgaySinh'])?></td><td><?=number_format((float)$n['Luong'],0,',','.')?></td><td><?=h($n['TenPB'])?></td><td><form method="post" onsubmit="return xacNhanXoa();"><input type="hidden" name="MaNV" value="<?=h($n['MaNV'])?>"><button class="xoa" name="xoa" value="1">Xóa</button></form></td></tr><?php endwhile; ?>
</tbody></table></div></main></body></html>
