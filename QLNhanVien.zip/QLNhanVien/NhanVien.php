<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli('localhost', 'root', '', 'QLNhanVien');
$conn->set_charset('utf8mb4');
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$loi = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 try {
  if (isset($_POST['them'])) {
   $ma = trim($_POST['MaNV'] ?? '');
   $ten = trim($_POST['HoTen'] ?? '');
   $ngay = $_POST['NgaySinh'] ?? '';
   $luong = $_POST['Luong'] ?? '';
   $pb = filter_var($_POST['MaPB'] ?? '', FILTER_VALIDATE_INT);
   $date = DateTime::createFromFormat('!Y-m-d', $ngay);
   if ($ma === '' || mb_strlen($ma) > 4 || $ten === '' || mb_strlen($ten) > 100 || !$date || $date->format('Y-m-d') !== $ngay || !preg_match('/^\d{1,12}$/D', $luong) || !$pb) {
    throw new Exception('Vui lòng nhập đầy đủ và đúng định dạng.');
   }
   $stmt = $conn->prepare('INSERT INTO NhanVien (MaNV,HoTen,NgaySinh,Luong,MaPB) VALUES (?,?,?,?,?)');
   $stmt->bind_param('ssssi', $ma,$ten,$ngay,$luong,$pb);
   $stmt->execute();
  } elseif (isset($_POST['xoa'])) {
   $ma = $_POST['MaNV'] ?? '';
   $stmt = $conn->prepare('DELETE FROM NhanVien WHERE MaNV=?');
   $stmt->bind_param('s',$ma);
   $stmt->execute();
  }
  header('Location: NhanVien.php'); exit;
 } catch (mysqli_sql_exception $e) {
  $loi = $e->getCode() == 1062 ? 'Mã nhân viên đã tồn tại.' : 'Không thể thực hiện thao tác. Kiểm tra dữ liệu phòng ban.';
 } catch (Exception $e) { $loi = $e->getMessage(); }
}
$phongban = $conn->query('SELECT MaPB, TenPB FROM PhongBan ORDER BY MaPB');
$nhanvien = $conn->query('SELECT n.MaNV,n.HoTen,n.NgaySinh,n.Luong,p.TenPB FROM NhanVien n JOIN PhongBan p ON n.MaPB=p.MaPB ORDER BY n.MaNV');
?>
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý nhân viên</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,sans-serif;font-size:14px;background:#fff;margin:0;padding:25px}.khung{max-width:900px;margin:auto;padding:16px;box-shadow:0 0 8px #ddd;border-radius:6px}.nhap{background:#fcf2e4;border:1px solid #eee1d1;padding:24px 18px;margin-bottom:10px}label{display:block;font-weight:bold;margin-bottom:8px}label span{color:#c43b23}.nhom{margin-bottom:16px}input,select{display:block;width:420px;max-width:95%;margin-left:4%;padding:8px;border:1px solid #aaa;border-radius:4px;background:white;font:inherit}button.them{margin-left:4%;background:#e98020;color:white;border:1px solid #c96b15;border-radius:5px;padding:10px;cursor:pointer;font-weight:bold}button.them:hover{background:#c96b15}table{border-collapse:collapse;width:100%}th,td{border:1px solid #e6ded4;padding:9px}th{background:#ed811d;color:white}tr:hover td{background:#fcf0df}td:nth-child(4){text-align:right}td:last-child{text-align:center}.xoa{border:0;background:none;color:#0000cc;text-decoration:underline;cursor:pointer;font:inherit}.loi{color:#b42318}.bang{overflow-x:auto}
</style></head><body><main class="khung">
<?php if ($loi): ?><p class="loi"><?=h($loi)?></p><?php endif; ?>
<form class="nhap" method="post">
<div class="nhom"><label for="MaNV">Mã nhân viên <span>*</span></label><input id="MaNV" name="MaNV" maxlength="4" required></div>
<div class="nhom"><label for="HoTen">Họ tên <span>*</span></label><input id="HoTen" name="HoTen" maxlength="100" required></div>
<div class="nhom"><label for="NgaySinh">Ngày sinh <span>*</span></label><input type="date" id="NgaySinh" name="NgaySinh" required></div>
<div class="nhom"><label for="Luong">Lương <span>*</span></label><input type="number" id="Luong" name="Luong" min="0" max="999999999999" step="1" required></div>
<div class="nhom"><label for="MaPB">Phòng ban <span>*</span></label><select id="MaPB" name="MaPB" required><option value="">-- Chọn phòng ban --</option><?php while($p=$phongban->fetch_assoc()): ?><option value="<?=h($p['MaPB'])?>"><?=h($p['TenPB'])?></option><?php endwhile; ?></select></div>
<button class="them" name="them" value="1">Thêm NV</button></form>
<div class="bang"><table><thead><tr><th>Mã NV</th><th>Họ tên</th><th>Ngày sinh</th><th>Lương</th><th>Tên phòng ban</th><th>Thao tác</th></tr></thead><tbody>
<?php while($n=$nhanvien->fetch_assoc()): ?><tr><td><?=h($n['MaNV'])?></td><td><?=h($n['HoTen'])?></td><td><?=h($n['NgaySinh'])?></td><td><?=number_format((float)$n['Luong'],0,',','.')?></td><td><?=h($n['TenPB'])?></td><td><form method="post" onsubmit="return confirm('Bạn có chắc muốn xóa nhân viên này?');"><input type="hidden" name="MaNV" value="<?=h($n['MaNV'])?>"><button class="xoa" name="xoa" value="1">Xóa</button></form></td></tr><?php endwhile; ?>
</tbody></table></div></main></body></html>
